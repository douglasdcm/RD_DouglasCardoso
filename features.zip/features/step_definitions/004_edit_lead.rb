When("I select the option Add Company") do
  element = @driver.find_element :xpath => ".//*[@id='leads_crm']/div[1]/div/div[2]/div/button"
  element.click #click on arrow button
  element = @driver.find_element :link_text => "Add company"
  element.click #click on Insert Lead button
  element = @driver.find_element :class_name => "container-nav-pills"
  element.text.include? "New Company"
end

When("I fill the field company $x") do |company|
  element = @driver.find_element :id => "inputNameCompany"
  element.send_keys company
end

When("The company $x is created") do |company|
  element = @driver.find_element :id => "company_name"
  element.text.include? company
  step "I loggout the app" 
end