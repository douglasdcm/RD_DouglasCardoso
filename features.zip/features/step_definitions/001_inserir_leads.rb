require 'selenium-cucumber'

Given ("I am loggedin") do
  @driver = Selenium::WebDriver.for :chrome
  @driver.manage.timeouts.implicit_wait = 10
  @driver.get "https://app-staging.rdstation.com.br/"
  element = @driver.find_element :id => "user_email"
  element.send_keys "douglas.dcm@gmail.com"
  element = @driver.find_element :id => "user_password"
  element.send_keys "123456"
  element = @driver.find_element :name => "commit"
  element.click
end

Given("I should be on Leads Base page") do
  step "I am loggedin"
  @driver.get "https://app-staging.rdstation.com.br/leads"
  sleep 2
  element = @driver.find_element :class_name => "container"
  element.text.include? "Leads Base"
end

When("I select the option Insert Lead") do
  element = @driver.find_element :xpath => ".//*[@id='leads_crm']/div[1]/div/div[2]/div/button"
  element.click #click on arrow button
  element = @driver.find_element :class_name => "add-link-button"
  element.click #click on Insert Lead button
  element = @driver.find_element :class_name => "container-nav-pills"
  element.text.include? "Insert Lead"
end

When("I fill the field email $x") do |email|  
  element = @driver.find_element :id => "lead_email"
  element.send_keys email
end

When("I save the form") do
  element = @driver.find_element :name => "commit"
  element.click
end

Then("The lead $x is created") do |email|
  element = @driver.find_element :id => "lead-name"
  element.text.include? email
  sleep 3
  step "I loggout the app"
end

Then("I loggout the app") do
  sleep 3
  element = @driver.find_element :class_name => "navbar-account-name"
  element.click
  element = @driver.find_element :link_text => "Log out"
  element.click
  element = @driver.find_element :css => "#login>h4>b"
  element.text.include? "Olá"
  @driver.quit
end

