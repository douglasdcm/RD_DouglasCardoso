Given("I should be on a leads page $x") do |lead|
  step "I should be on Leads Base page"
  element = @driver.find_element :id => "query"
  element.send_keys lead
  element.send_keys :return
  sleep 2
  element = @driver.find_element :link_text => lead
  element.click
  element = @driver.find_element :id => "lead-name"
  element.text.include? lead
end

When("I select the option Edit") do
  element = @driver.find_element :link_text => "Edit"
  element.click
end

And("I fill the field lead owner using $x") do |lead_owner|
  element = @driver.find_element :xpath => ".//*[@id='lead_user_id']/option[text()='#{lead_owner}']"
  element.click
end

And("I fill the field lead stage using $x") do |hopper_stage|
  element = @driver.find_element :xpath => ".//*[@id='lead_lifecycle_stage']/option[text()='#{hopper_stage}']"
  element.click
end

Then("The lead $x is updated") do |lead|
  element = @driver.find_element :css => ".col-xs-9>p"
  element.text.include? "Had its stage in the funnel changed"
  step "I loggout the app"
end


