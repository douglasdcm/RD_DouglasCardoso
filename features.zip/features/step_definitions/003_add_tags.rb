When("I select the option Add Tag") do
  element = @driver.find_element :xpath => ".//*[@id='search_form']/div[2]/div/div[3]/div[1]/button"
  element.click
  element = @driver.find_element :link_text => "Add tag"
  element.click
  element = @driver.find_element :class_name => "modal-title"
  element.text.include? "Add tag"
end

When("I fill the field tag $x") do |tag|
  element = @driver.find_element :id => "add-tags-input"
  element.send_keys tag
end

When("I request for the addition") do
  element = @driver.find_element :name => "button"
  element.click
end

Then("A mesage informing the addition was sucsselful is shown") do
  sleep 3
  element = @driver.find_element :xpath => "//body/div[5]"
  element.text.include? "The tag will be added to the selected Leads within moments."
  step "I loggout the app"
end

