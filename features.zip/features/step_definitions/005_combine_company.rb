Given("I should be on a existing company page $x") do |company|
  step "I should be on Leads Base page"
  element = @driver.find_element :link_text => "Companies"
  element.click
  element = @driver.find_element :xpath => ".//*[@id='table-company-index']/thead/tr/th[1]"
  element.text.include? "Company"
  element = @driver.find_element :id => "query"
  element.send_keys company
  element.send_keys :return
  sleep 2
  element = @driver.find_element :link_text => company
  element.click
  element = @driver.find_element :id => "company_name"
  element.text.include? company
end

When("I select the option Combine") do
  element = @driver.find_element :css => ".btn.btn-default.dropdown-toggle"
  element.click
  element = @driver.find_element :link_text => "Combine"
  element.click
  element = @driver.find_element :id => "change_companyLabel"
  element.text.include? "combine companies"
end

When("I search for a second company $x") do |company|
  element = @driver.find_element :id => "merge-company-query"
  element.send_keys company
  sleep 2
  element.click
  sleep 1
  element = @driver.find_element :xpath => ".//*[@id='change_company']/div/div/form/div[2]/div[1]/span/span[2]/div/span/div/p[text()='#{company}']"
  element.click
end

When("I request for combination") do
  element = @driver.find_element :id => "merge-company-btn"
  element.click
end

Then("A mesage informing the combination was sucsselful is shown") do
  sleep 3
  element = @driver.find_element :xpath => "//body/div[5]"
  element.text.include? "The companies will be combined in a few minutes!"
  step "I loggout the app"
end

